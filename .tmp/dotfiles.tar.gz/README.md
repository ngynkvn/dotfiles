# dotfiles via chezmoi

My dotfiles!

## Test

```bash
  docker build -t chez:latest --progress=plain --no-cache . && docker run --rm -it chez:latest bash

```
